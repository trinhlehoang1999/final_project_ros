/*
 * mainpp.cpp
 *
 *  Created on: Sep 21, 2021
 *      Author: neo_hoang
 */
#include <mainpp.h>
#include <ros.h>
#include "tim.h"
#include "dma.h"
#include "tim.h"
#include "gpio.h"
#include "stdio.h"
#include "math.h"
#include "stdlib.h"
#include <std_msgs/UInt32.h>
#include <std_msgs/Bool.h>// bool run or stop
#include <std_msgs/Float32.h>// pub data imu
#include <geometry_msgs/Twist.h>// get cmdvel
//////////////////////////
#define Ts_ 0.01
//////////////////////////
ros::NodeHandle nh;
/////////////////
std_msgs::UInt32 num_msg_l,num_msg_r;// pub_enc
std_msgs::Float32 data_imu_msg;//pub imu data
////////////////////////////////
ros::Publisher num_pub_l("num_left", &num_msg_l);
ros::Publisher num_pub_r("num_right", &num_msg_r);
ros::Publisher imu_pub("data_imu", &data_imu_msg);
////////////////////////////////

////////////////////////////////
uint32_t nowtick = 0;
uint32_t pasttick = 0;
uint32_t num_test = 0;
uint8_t duty = 0;
bool flag_run = false;
///////////////////////////
uint8_t sig_imu_data = 'z';
uint8_t sig_imu_reset = 'a';
uint8_t data_h = 0, data_l = 0;
int16_t data = 0;
uint8_t rxBuffer[2] ;
uint8_t flag = 0;
float get_imu = 0;
////////////////////////////
uint32_t data_count;
float speed_ang = 0,speed_lin = 0 ;
float w_r = 0, w_l =  0;
float wheel_rad = 0.0325, wheel_sep = 0.2;
const float PI = 3.1415;
///////////////////////////////
int32_t get_enc_value = 0;
float vel_ms = 0;

//////////////////////////////
float l_Kp = 0, l_Ki = 0, l_Kd = 0;
float l_ek=0 ,l_ek_1 = 0,l_ek_2 = 0;
float l_uk = 0,l_uk1 = 0, l_uk_1 = 0;
float l_Vref = 0;
float l_Vc = 0;
///////////////////////////////////
float r_Kp = 0, r_Ki = 0, r_Kd = 0;
float r_ek=0 ,r_ek_1 = 0,r_ek_2 = 0;
float r_uk = 0,r_uk1 = 0, r_uk_1 = 0;
float r_Vref = 0;
float r_Vc = 0;
//////////////////////////////////

float rev_angle_enc = 0;
///////////////////////////////
uint8_t ON = 0;
///////////////////////////////
uint8_t time_tick_1ms = 0;
uint8_t time_tick_10ms = 0;
uint16_t time_tick_100ms = 0;
/////////////////////////////
void check_operation_callback(const std_msgs::Bool& msg);
void reset_mcu(const std_msgs::Bool& msg);
void get_vel(const geometry_msgs::Twist& msg);
void serial_init_imu(void);
float my_motorVel_L(void);
float my_motorVel_R(void);
void PID_init_R(float _Kp,float _Ki,float _Kd);
void PID_init_L(float _Kp,float _Ki,float _Kd);
void process_PID_R(float _Vref, float _Vc);
void process_PID_L(float _Vref, float _Vc);
void reset_PID(void);
float Saturation(float _uk);
void kinetic_robot(float spd_ang,float spd_lin);
//long map(long x, long in_min, long in_max, long out_min, long out_max);

void reset_imu(void);
int16_t data_imu(void);
int16_t suraion_imu();
///////////////////////////////////
ros::Subscriber<std_msgs::Bool> flag_run_sub("flag_run", &check_operation_callback);// get bool
ros::Subscriber<std_msgs::Bool> reset_mcu_sub("reset_mcu", &reset_mcu);// get bool
ros::Subscriber<geometry_msgs::Twist> vel_sub("cmd_vel", &get_vel);// get cmdvel
///////////////////////////////////
extern UART_HandleTypeDef huart1;
//////////////////////
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart){
	if(huart->Instance == USART2)
	{
		nh.getHardware()->flush();
	}
}
//////////////////////////////////
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	if(huart->Instance == USART2){
		nh.getHardware()->reset_rbuf();
	}
	else if(huart->Instance == USART1){
		HAL_UART_Receive_IT(&huart1, rxBuffer, 2);
	}
  }
/////////////////////////////////////
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
		if(htim->Instance == TIM6)
		{
			time_tick_1ms = 1;
		}
}
//////////////////////////////////
void check_operation_callback(const std_msgs::Bool& msg){
  if(msg.data == true){
//	  if (flag_run == true){
//		  flag_run = false;
		  ON = 0;
  } else if(flag_run == false){
//		  flag_run = true;
		  ON = 1;
	  }
  }
//}
//////////////////////////////////
void reset_mcu(const std_msgs::Bool& msg){
  //duty = msg.data;
	if(msg.data == true){
		HAL_NVIC_SystemReset();
	}
}
//////////////////////////////////

void get_vel( const geometry_msgs::Twist& msg){

  speed_ang = msg.angular.z;

  speed_lin = msg.linear.x;

//  w_r = ((speed_lin/wheel_rad) + ((speed_ang*wheel_sep)/(2.0*wheel_rad)))/(2*PI); // m/s

//  w_l = ((speed_lin/wheel_rad) - ((speed_ang*wheel_sep)/(2.0*wheel_rad)))/(2*PI); // m/s


}
////////////////////////////////////////////////
void kinetic_robot(float spd_ang,float spd_lin){

	  w_r = ((spd_lin/wheel_rad) + ((spd_ang*wheel_sep)/(2.0*wheel_rad)))*30/PI; // vong/phut
	//
	  w_l = ((spd_lin/wheel_rad) - ((spd_ang*wheel_sep)/(2.0*wheel_rad)))*30/PI; // vong/phut
}
////////////////////////////////////////////////
void reset_imu(){
	HAL_UART_Transmit_IT(&huart1, (uint8_t *) &sig_imu_reset, 1);
}


void serial_init_imu(){
	  HAL_UART_Receive_IT(&huart1, rxBuffer, 2);
	  reset_imu();
	  reset_imu();
}

int16_t data_imu(){
	  HAL_UART_Transmit_IT(&huart1,(uint8_t *) &sig_imu_data, 1);
	  uint8_t data_h;
	  uint8_t data_l;
	  data_h = rxBuffer[0];
	  data_l = rxBuffer[1];
	  HAL_Delay(2);
	  int16_t  data = (int16_t) ((data_h<<8) | data_l)/10;
	  //data = map(data, 0, 3570, 0, 3600);
	  return data;
}

int16_t suraion_imu(){
	  int16_t _data_imu;
	  //static int16_t map_imu;
	  static int16_t s_data_imu ;
    _data_imu = data_imu();
  if (s_data_imu >= 181)
  {
    flag = 1;
    reset_imu();
    //reset_imu();
    _data_imu = 0;
  }
  else if (s_data_imu <= -181)
  {
    flag = 2;
    reset_imu();
    //reset_imu();
    _data_imu = 0;
  }
  else
  {
    s_data_imu =  _data_imu;
  }

  if (flag == 1)
  {
    s_data_imu = -180 + _data_imu;
  }
  else if (flag == 2)
  {
    s_data_imu = 180 + _data_imu;
  }

  return s_data_imu;
}
////////////////////////////////////////////
float my_motorVel_R()
{
	static int16_t enc_current = 0, enc_pre = 0;
	float vel= 0;
	enc_current = __HAL_TIM_GetCounter(&htim1);

	float pulse_cnt = enc_current - enc_pre;

	if (pulse_cnt >= 32768)
	{
		pulse_cnt -= 65536;
	}
	else if (pulse_cnt <= -32768)
	{
		pulse_cnt += 65536;
	}

	vel = (pulse_cnt*100*60.0)/1332;
	//vel_ms = (vel*20.42)/6000;
	enc_pre = enc_current;
	return vel;
}

float my_motorVel_L()
{
	static int16_t enc_current = 0, enc_pre = 0;
	float vel= 0;
	enc_current = __HAL_TIM_GetCounter(&htim4);

	float pulse_cnt = enc_current - enc_pre;

	if (pulse_cnt >= 32768)
	{
		pulse_cnt -= 65536;
	}
	else if (pulse_cnt <= -32768)
	{
		pulse_cnt += 65536;
	}

	vel = (pulse_cnt*100*60.0)/1332;
	//vel_ms = (vel*20.42)/6000;
	enc_pre = enc_current;
	return vel;
}
////////////////////////////////////////////
void PID_init_R(float _Kp,float _Ki,float _Kd)
{
	r_Kp = _Kp;
	r_Ki = _Ki;
	r_Kd = _Kd;
	r_ek = 0;
	r_ek_1 = 0;
	r_ek_2 = 0;
	r_uk = 0;
	r_uk_1 = 0;
}

void process_PID_R(float _Vref, float _Vc)
{
	r_ek = _Vref - _Vc;
	r_uk = r_uk_1 + r_Kp*(r_ek-r_ek_1)
				+ r_Ki*Ts_*(r_ek + r_ek_1)*0.5
				+ r_Kd*(r_ek-2*r_ek_1+r_ek_2)/Ts_;
	r_uk_1 = r_uk;
	r_ek_2 = r_ek_1;
	r_ek_1 = r_ek;

	r_uk1 = r_uk;

	if(r_uk1 > 0){
		r_uk1 = Saturation(r_uk1);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
		//__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,uk1);
		//__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,0);
	}else if (r_uk1 < 0){
		r_uk1 = Saturation(r_uk1);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
		//__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
		//__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,uk1);
	}
	if (_Vref == 0)
	{

		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
	}
	__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,r_uk1);
}
////////////////////////////////////////////
void PID_init_L(float _Kp,float _Ki,float _Kd)
{
	l_Kp = _Kp;
	l_Ki = _Ki;
	l_Kd = _Kd;
	l_ek = 0;
	l_ek_1 = 0;
	l_ek_2 = 0;
	l_uk = 0;
	l_uk_1 = 0;
}

void reset_PID()
{
	l_ek = 0;
	l_ek_1 = 0;
	l_ek_2 = 0;
	l_uk = 0;
	l_uk_1 = 0;
//	w_l = 0;
//	l_Vref = 0;
//	l_Vc = 0;

//
//	r_Vref = 0;
//	r_Vc = 0;
	r_ek = 0;
	r_ek_1 = 0;
	r_ek_2 = 0;
	r_uk = 0;
	r_uk_1 = 0;
//	w_r = 0;

	rev_angle_enc = 0;
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_1, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, GPIO_PIN_RESET);
	__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,0);
	__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
}

float Saturation(float _uk)
{
	if(_uk < 0) _uk =  abs(_uk);

	if(_uk < 50) _uk = 0;

	if(_uk > 98) _uk = 98;

	return _uk;
}

void process_PID_L(float _Vref, float _Vc)
{
	l_ek = _Vref - _Vc;
	l_uk = l_uk_1 + l_Kp*(l_ek-l_ek_1)
				+ l_Ki*Ts_*(l_ek + l_ek_1)*0.5
				+ l_Kd*(l_ek-2*l_ek_1+l_ek_2)/Ts_;
	l_uk_1 = l_uk;
	l_ek_2 = l_ek_1;
	l_ek_1 = l_ek;

	l_uk1 = l_uk;

	if(l_uk1 > 0){
		l_uk1 = Saturation(l_uk1);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, GPIO_PIN_SET);
		//__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,uk1);
		//__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,0);
	}else if (l_uk1 < 0){
		l_uk1 = Saturation(l_uk1);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, GPIO_PIN_RESET);
		//__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,0);
		//__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,uk1);
	}
	if (_Vref == 0)
	{
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_3, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, GPIO_PIN_RESET);
	}
	__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_3,l_uk1);
}
////////////////////////////////////////////
void setup(void)
{

  serial_init_imu();
  nh.initNode();
  nh.subscribe(flag_run_sub);// check run or stop
  nh.subscribe(reset_mcu_sub);
  nh.subscribe(vel_sub); // sub cmd_vel to control wr and wl
  nh.advertise(num_pub_l); // pub tick encoder left
  nh.advertise(num_pub_r); // pub tick encoder righ
  nh.advertise(imu_pub); // pub imu data (rad)

  r_Vref = 0;
  l_Vref = 0;
  r_Vc = 0;
  l_Vc = 0;
  ON = 1;
  reset_PID();
  reset_imu();
  duty = 0;
  PID_init_R(3.2,0.36,0.010);
  PID_init_L(3.2,0.36,0.010);
}
////////////////////////////////////////////
//long map(long x, long in_min, long in_max, long out_min, long out_max) {
//  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
//}

/////////////////////////////////////////////
void loop(void)
{

	if (time_tick_1ms == 1){
		time_tick_10ms ++;
		time_tick_100ms ++;
		time_tick_1ms = 0;

	}
	if (time_tick_10ms == 10){
		r_Vc = my_motorVel_R();
		l_Vc = -my_motorVel_L();
		if (ON == 1)
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
			kinetic_robot(speed_ang,speed_lin);
			process_PID_R(w_r,r_Vc);
			process_PID_L(w_l,l_Vc);
		}
		else
		{
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
			reset_PID();
			r_uk = 0;
			l_uk = 0;
			//PID_init_R(r_Kp,r_Ki,r_Kd);
			//PID_init_L(l_Kp,l_Ki,l_Kd);
			r_Vc = 0;
			l_Vc = 0;
		}
		time_tick_10ms = 0;
	}
	if (time_tick_100ms == 100){
		//get_imu =(float) suraion_imu()*PI/180;
		//get_imu = suraion_imu();
		if(nh.connected()){

			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);
			get_imu =(float) suraion_imu()*PI/180;
			data_imu_msg.data = get_imu;
			num_msg_l.data = TIM4->CNT;
			num_msg_r.data = TIM1->CNT;
			num_pub_l.publish(&num_msg_l);
			num_pub_r.publish(&num_msg_r);
			imu_pub.publish(&data_imu_msg);
		}
		else{
			 HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6,GPIO_PIN_SET);
			 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET);
		}
		time_tick_100ms = 0;
	}
	nh.spinOnce();
	/////////////////////////////////////////////////////////////////
//	nowtick = HAL_GetTick();
//	if (nowtick - pasttick > 10)
//	{
//		if(nh.connected())
//		{
//			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_SET);
//			get_imu =(float) suraion_imu()*PI/180;
//			data_imu_msg.data = get_imu;
//			num_msg_l.data = TIM1->CNT;
//			num_msg_r.data = TIM4->CNT;
//			num_pub_l.publish(&num_msg_l);
//			num_pub_r.publish(&num_msg_r);
//			imu_pub.publish(&data_imu_msg);
//			num_test++;
//			__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,duty);
//
//		}
//		else HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_RESET);
//
//		pasttick = nowtick;
//
//	}
//	nh.spinOnce();
	//////////////////////////////////////////////////////////////////////

}
